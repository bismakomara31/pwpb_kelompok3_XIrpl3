<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <title>Kelompok3</title>

    <style type="text/css">
    #footer{
        position: static;
        bottom: 0px;
        left: 547px;
    }
    </style>

  </head>
  <body>
    <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-primary">
      <div class="container">
      <a class="navbar-brand" href="index.php"><p class="h4">Beranda</p></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <a class="nav-link" href="tugas_pertama.php"><p class="h5">Tugas Pertama</p></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="tugas_kedua.php"><p class="h5">Tugas Kedua</p></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="tugas_ketiga.php"><p class="h5">Tugas Ketiga</p></a>
          </li>
        </ul>
        <form class="form-inline my-2 my-lg-0">
          <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-light my-2 my-sm-0" type="submit">Search</button>
        </form>
      </div>
      </div>
    </nav>
     <div class="container">
          <div class="jumbotron jumbotron-fluid">
            <div class="container">
            	<h2>Berikut hasil Biodata anda:<br></h2>
<?php 
if(isset($_POST['spn'])){
	if(isset($_POST['nml'])){
		echo "Nama : ".$_POST['nml']."<br>";
	}
	if(isset($_POST['nmp'])){
		echo "Nama Panggilan : ".$_POST['nmp']."<br>";
	}
	if(isset($_POST['radio'])){
		echo "Jenis Kelamin : ".$_POST['radio']."<br>";
	}
	if(isset($_POST['nisn'])){
		echo "NISN : ".$_POST['nisn']."<br>";
	}
	if(isset($_POST['nik'])){
		echo "NIK : ".$_POST['nik']."<br>";
	}
	if(isset($_POST['ttl'])){
		echo "Tempat dan tanggal lahir : ".$_POST['ttl']."<br>";
	}
	if(isset($_POST['nskhu'])){
		echo "Nomor SKHU : ".$_POST['nskhu']."<br>";
	}
	if(isset($_POST['tglskl'])){
		echo "Tanggal diterima disekolah ini : ".$_POST['tglskl']."<br>";
	}
	if(isset($_POST['alasan'])){
		echo "Jika pindahan, sebutkan alasan pindah kesekolah ini : ".$_POST['nisn']."<br>";
	}
	if(isset($_POST['agama'])){
		echo "Agama : ".$_POST['agama']."<br>";
	}
	if(isset($_POST['almt'])){
		echo "Alamat : ".$_POST['almt']."<br>";
	}
	if(isset($_POST['tinggal'])){
		echo "Tinggal bersama : ".$_POST['tinggal']."<br>";
	}
	if(isset($_POST['trans'])){
		echo "Transportasi ke sekolah : ".$_POST['trans']."<br>";
	}
	if(isset($_POST['notlp'])){
		echo "Nomor tlpn : ".$_POST['notlp']."<br>";
	}
	if(isset($_POST['nokps'])){
		echo "Nomor KPS (jika punya) : ".$_POST['nokps']."<br>";
	}
	echo "<b>Data ayah kandung </b>"."<br>";
	if(isset($_POST['nmayah'])){
		echo "Nama : ".$_POST['nmayah']."<br>";
	}
	if(isset($_POST['ttlayah'])){
		echo "Tahun lahir : ".$_POST['ttlayah']."<br>";
	}
	if(isset($_POST['pddknayah'])){
		echo "Pendidikan : ".$_POST['pddknayah']."<br>";
	}
	if(isset($_POST['pkjnayah'])){
		echo "Pekerjaan : ".$_POST['pkjnayah']."<br>";
	}
		if(isset($_POST['in'])){
		echo "Penghasilan : ".$_POST['in']."<br>";
	}

	echo "<b> Data Ibu kandung </b> "."<br>";
	if(isset($_POST['nmibu'])){
		echo "Nama : ".$_POST['nmibu']."<br>";
	}
	if(isset($_POST['ttlibu'])){
		echo "Tahun lahir : ".$_POST['ttlibu']."<br>";
	}
	if(isset($_POST['pddknibu'])){
		echo "Pendidikan : ".$_POST['pddknibu']."<br>";
	}
	if(isset($_POST['pkjnibu'])){
		echo "Pekerjaan : ".$_POST['pkjnibu']."<br>";
	}
	if(isset($_POST['inc'])){
		echo "Penghasilan : ".$_POST['inc']."<br>";
	}
}
?>
</div>
        </div>
          <div id="container">
            <div id="footer">
              <blockquote class="blockquote">
              <center>
                <p><cite title="Source Title">©2019 Designed by Kelompok 3</cite></p>
              </center>
              </blockquote>
            </div>
          </div>
    </div>
       <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>