<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <title>Kelompok3</title>

    <style type="text/css">
    #footer{
        position: static;
        bottom: 0px;
        left: 547px;
    }
    input[type="text"]{
      background-color: #eaeaea; 
    }
    input[type="date"]{
      background-color: #eaeaea;
    }
    select{
      background-color: #eaeaea;
    }
    </style>

  </head>
  <body>
    <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-primary">
      <div class="container">
      <a class="navbar-brand" href="index.php"><p class="h4">Beranda</p></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <a class="nav-link" href="tugas_pertama.php"><p class="h5">Tugas Pertama</p></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="tugas_kedua.php"><p class="h5">Tugas Kedua</p></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="tugas_ketiga.php"><p class="h5">Tugas Ketiga</p></a>
          </li>
        </ul>
        <form class="form-inline my-2 my-lg-0">
          <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-light my-2 my-sm-0" type="submit">Search</button>
        </form>
      </div>
      </div>
    </nav> 
      <div class="container">
        <div class="jumbotron jumbotron-fluid">
          <div class="container">
          <div class="h3">Tugas Form Biodata</div>            
              <form action="form.proses.php" method="POST">
                <table width="75%" height="60%" border="0" align="center">
                  <tr align="center">
                    <td colspan="2"><b>DATA IDENTITAS PESETA DIDIK BARU<br>
                    TAHUN AJARAN 2019/2020</td>
                  </tr> 
                  <tr>
                    <td>Nama Lengkap:</td>
                    <td><input type="text" name="nml" size="30"></td>
                  </tr>
                  <tr>
                    <td>Nama Panggilan:</td>
                    <td><input type="text" name="nmp" size="30"></td>
                  </tr>
                  <tr>
                    <td>Jenis Kelamin</td>
                    <td>
                      <input type="radio" name="radio" value="laki-laki">Laki-Laki
                      <input type="radio" name="radio" value="perempuan">Perempuan
                    </td>
                  </tr>
                  <tr>
                    <td>NISN:</td>
                    <td><input type="text" name="nisn" size="30"></td>
                  </tr>
                  <tr>
                    <td>NIK:</td>
                    <td><input type="text" name="nik" size="30"></td>
                  </tr>
                  <tr>
                    <td>Tempat dan Tanggal Lahir:</td>
                    <td><input type="text" name="ttl" size="15"><input type="date" ></td>
                  </tr>
                  <tr>
                    <td>Nomor SKHU:</td>
                    <td><input type="text" name="nskhu" size="30"></td>
                  </tr>
                  <tr>
                    <td>Tanggal diterima disekolah ini:</td>
                    <td><input type="text" name="tglskl" size="30"></td>
                  </tr>
                  <tr>
                    <td>Jika pindahan, sebutkan alasan pindah kesekolah ini:</td>
                    <td><input type="text" name="alasan" size="30"></td>
                  </tr>
                  <tr>
                    <td>Agama:</td>
                    <td>
                      <select  name="agama" size="1">
                        <option>Islam</option>
                        <option>Kristen Katolik</option>
                        <option>Kristen Protestant</option>
                        <option>Budha</option>
                        <option>Hindu</option>
                        <option>dll</option>
                      </select>
                    </td>
                  </tr>
                  <tr>
                  <tr>
                    <td>Alamat:</td>
                    <td><input type="text" name="almt" size="30"></td>
                  </tr>
                  <tr>
                    <td>Tinggal bersama:</td>
                    <td>
                      <input type="radio" name="tinggal" value="Orang tua">Orang tua
                      <input type="radio" name="tinggal" value="Asrama">Asrama<br>
                    </td>
                  </tr>
                  <tr>
                    <td>Transportasi ke sekolah:</td>
                    <td><input type="text" name="trans" size="30"></td>
                  </tr>
                  <tr>
                    <td>Nomor tlpn:</td>
                    <td><input type="text" name="notlp" size="30"></td>
                  </tr>
                  <tr>
                  <tr>
                    <td>Nomor KPS (jika punya):</td>
                    <td><input type="text" name="nokps" size="30"></td>
                  </tr>
                  <tr>
                    <td colspan="2"><b>Data Ayah kandung</b></td>
                  </tr>
                  <tr>
                    <td>Nama:</td>
                    <td><input type="text" name="nmayah" size="30"></td>
                  </tr>
                  <tr>
                    <td>Tahun lahir:</td>
                    <td><input type="text" name="ttlayah" size="30"></td>
                  </tr>
                  <tr>
                    <td>Pendidikan:</td>
                    <td><input type="text" name="pddknayah" size="30"></td>
                  </tr>
                  <tr>
                    <td>Pekerjaan:</td>
                    <td><input type="text" name="pkjnayah" size="30"></td>
                  </tr>
                  <tr>
                    <td>Penghasilan:</td>
                    <td>
                      <input type="radio" name="in" value="500.000">Rp50.000-Rp500.000 
                      <input type="radio" name="in" value="1.000.000">Rp600.000-Rp1.000.000<br>
                      <input type="radio" name="in" value="2.000.000">Rp1.000.000-Rp2.000.000
                      <input type="radio" name="in" value="2.000.000++">Rp.2.000.000++<br>
                    </td>
                  </tr>
                  <tr>
                    <td colspan="2"><b>Data Ibu kandung</b></td>
                  </tr>
                  <tr>
                    <td>Nama:</td>
                    <td><input type="text" name="nmibu" size="30"></td>
                  </tr>
                  <tr>
                    <td>Tahun lahir:</td>
                    <td><input type="text" name="ttlibu" size="30"></td>
                  </tr>
                  <tr>
                    <td>Pendidikan:</td>
                    <td><input type="text" name="pddknibu" size="30"></td>
                  </tr>
                  <tr>
                    <td>Pekerjaan:</td>
                    <td><input type="text" name="pkjnibu" size="30"></td>
                  </tr>
                  <tr>
                    <td>Penghasilan:</td>
                    <td>
                      <input type="radio" name="inc" value="500.000">Rp50.000-Rp500.000 
                      <input type="radio" name="inc" value="1.000.000">Rp600.000-Rp1.000.000<br>
                      <input type="radio" name="inc" value="2.000.000">Rp1.000.000-Rp2.000.000
                      <input type="radio" name="inc" value="2.000.000++">Rp.2.000.000++<br>
                    </td>
                  </tr>
                  <tr align="center">
                    <td colspan="2">
                      <input type="submit" value="Simpan" name="spn">
                      <input type="reset" value="Reset" name="rst">
                    </td>
                  </tr>
                </table>
              </form>
            </div>
          </div>
        </div>
      </div>
        
<div class="container">
  <div id="footer">
    <blockquote class="blockquote">
    <center>
      <p><cite title="Source Title">©2019 Designed by Kelompok 3</cite></p>
    </center>
    </blockquote>
  </div>
</div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.3.1.slim.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
